package src;

public class Main
{
    public static void main(String[] args)
    {
        Input.input();
        Population.initPop();
        Population.printPop();
        Population.printTotalReleaseDate();
    }
}
